package com.example.bluetoothconnection;

public class MESSAGE_READ {
}
